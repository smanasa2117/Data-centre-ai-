/* DataCenter Guardian AI - dashboard (vanilla JS, no build step) */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const api = async (url, body) => {
  const r = await fetch(url, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {});
  const j = await r.json().catch(() => ({ error: "Bad response" }));
  if (!r.ok && !j.error) j.error = "Request failed";
  return j;
};
const toast = (m) => { const t = $("#toast"); t.textContent = m; t.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(() => t.hidden = true, 3200); };
const COL = { G: "#4cc9f0", T: "#f08c3a", P: "#7c9cff", C: "#2fbf71", D: "#c084fc", E: "#e8c547" };
const NAMES = { G: "GPU capacity", T: "Thermal headroom", P: "Power", C: "Cooling compat.", D: "Deadline/priority", E: "Energy/carbon" };
let OV = null, lastSim = null;

function md(t) {   // tiny, safe markdown: **bold**, *italic*, `code`, lists, paragraphs
  const inl = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/(^|\s)_(.+?)_(?=\s|$|[.,])/g, "$1<i>$2</i>").replace(/\*(.+?)\*/g, "<i>$1</i>").replace(/`(.+?)`/g, "<code>$1</code>");
  let out = "", list = null;
  for (const line of String(t).split("\n")) {
    const ul = line.match(/^\s*-\s+(.*)/), ol = line.match(/^\s*\d+\.\s+(.*)/);
    const kind = ul ? "ul" : ol ? "ol" : null;
    if (kind) { if (list !== kind) { out += (list ? `</${list}>` : "") + `<${kind}>`; list = kind; } out += `<li>${inl((ul || ol)[1])}</li>`; continue; }
    if (list) { out += `</${list}>`; list = null; }
    if (line.trim()) out += `<p>${inl(line)}</p>`;
  }
  return out + (list ? `</${list}>` : "");
}

/* ---------------- tabs ---------------- */
$("#tabs").addEventListener("click", e => { const b = e.target.closest("button"); if (b) show(b.dataset.tab); });
function show(tab) {
  document.querySelectorAll("nav button").forEach(b => b.classList.toggle("on", b.dataset.tab === tab));
  document.querySelectorAll(".tab").forEach(s => s.classList.toggle("on", s.id === tab));
  ({ overview: loadOverview, sim: renderSim, audit: loadAudit }[tab] || (() => { }))();
}

/* ---------------- overview ---------------- */
async function loadOverview() {
  OV = await api("/api/overview");
  const k = OV.kpis;
  $("#llmBadge").textContent = OV.llm ? "LLM mode" : "Demo agent (no API key)";
  const sel = $("#scenario");
  if (!sel.options.length) { sel.innerHTML = Object.entries(OV.scenarios).map(([k, v]) => `<option value="${k}" title="${esc(v)}">${k}</option>`).join(""); }
  sel.value = OV.scenario;
  const pb = $("#pendingBadge"); pb.hidden = !k.pending_approvals; pb.textContent = k.pending_approvals;
  $("#overview").innerHTML = `
  <div class="kpis">
    <div class="kpi"><b>${k.racks}</b><span>GPU racks · 4 clusters</span></div>
    <div class="kpi"><b style="color:var(--critical)">${k.critical}</b><span>Critical racks</span></div>
    <div class="kpi"><b style="color:var(--elevated)">${k.elevated}</b><span>Elevated racks</span></div>
    <div class="kpi"><b>${k.gpus_free}<small style="font-size:13px;color:var(--mute)"> / ${k.gpus_total}</small></b><span>GPUs free</span></div>
    <div class="kpi"><b>${k.it_load_kw} <small style="font-size:13px;color:var(--mute)">kW</small></b><span>IT load</span></div>
    <div class="kpi"><b>${k.pending_approvals}</b><span>Pending approvals</span></div>
  </div>
  <div class="grid2"><div>
    <h2>Clusters and racks <small style="color:var(--mute);font-weight:400">· thermal-stress score (0-100), click a rack for evidence</small></h2>
    ${OV.clusters.map(clusterCard).join("")}
  </div><div>
    <h2>Active alerts</h2>${OV.alerts.length ? OV.alerts.map(a => `<div class="alert ${a.severity}"><b>${esc(a.message)}</b>
      <small>${a.evidence.map(esc).join(" · ")} · confidence ${esc(a.confidence)}</small></div>`).join("") : `<div class="empty card">No active alerts</div>`}
    <h2>Workloads</h2><div class="card"><table><tr><th>ID</th><th>Where</th><th>GPUs</th><th>Priority</th></tr>
    ${OV.workloads.map(w => `<tr><td>${esc(w.workload_id)}</td><td>${w.cluster_id} / ${w.rack_id}</td><td>${w.gpu_required}</td><td>${esc(w.priority)}</td></tr>`).join("")}</table></div>
  </div></div>`;
}
function clusterCard(c) {
  const hd = c.thermal_headroom_kw;
  return `<div class="cluster"><div class="cl-h"><div><b>${esc(c.name)}</b> <small>${esc(c.gpu_model)} · ${esc(c.cooling_type.replace(/_/g, " "))}</small></div>
    <div class="meta"><span class="chip">${c.available_gpus}/${c.total_gpus} GPUs free</span>
    <span class="chip ${hd < 0 ? "bad" : hd < 40 ? "warn" : "good"}">thermal headroom ${hd} kW</span>
    <span class="chip">power headroom ${c.power_headroom_kw} kW</span>
    ${c.units.map(u => `<span class="chip ${u.performance < .75 ? "bad" : ""}">${esc(u.unit_id)} ${Math.round(u.performance * 100)}% · ${esc(u.status)}</span>`).join("")}</div></div>
    <div class="racks">${c.racks.map(r => `<button class="rack ${r.level}" onclick="openRack('${r.rack_id}')">
      <div class="id"><span>${r.rack_id}</span><span class="lvl">${r.level}</span></div><div class="sc">${r.score ?? "–"}</div>
      <small>${r.util != null ? Math.round(r.util) + "% GPU · " + Math.round(r.power_kw) + " kW" : "no data"}</small>
      <small>${r.inlet != null ? r.inlet.toFixed(1) + " °C inlet" : ""}${r.confidence !== "High" ? " · conf. " + r.confidence : ""}</small></button>`).join("")}</div></div>`;
}

/* ---------------- rack drawer ---------------- */
function line(vals, w, h, color, label, unit) {
  const mn = Math.min(...vals), mx = Math.max(...vals), pad = (mx - mn) * .15 || 1, lo = mn - pad, hi = mx + pad;
  const x = i => 34 + i * (w - 44) / (vals.length - 1 || 1), y = v => h - 18 - (v - lo) / (hi - lo) * (h - 30);
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" role="img" aria-label="${esc(label)} trend"><text x="4" y="12">${esc(label)} (${unit})</text>
   <line x1="34" y1="${h - 18}" x2="${w - 10}" y2="${h - 18}" stroke="#24324f"/>
   <text x="2" y="${y(hi - pad) + 3}">${(hi - pad).toFixed(0)}</text><text x="2" y="${y(lo + pad) + 3}">${(lo + pad).toFixed(0)}</text>
   <polyline fill="none" stroke="${color}" stroke-width="2" points="${vals.map((v, i) => `${x(i)},${y(v)}`).join(" ")}"/>
   <text x="34" y="${h - 4}">-4 h</text><text x="${w - 34}" y="${h - 4}">now</text></svg>`;
}
async function openRack(id) {
  const d = await api("/api/rack/" + id); if (d.error) return toast(d.error);
  const e = d.estimate, h = d.history;
  $("#drawerBody").innerHTML = `<div style="display:flex;justify-content:space-between;align-items:start"><div><h2 style="margin:0">${id} <span class="lvl ${e.level}" style="--c:var(--${e.level.toLowerCase()})">${e.level}</span></h2>
    <div class="meta" style="margin-top:6px"><span class="chip">stress ${e.score}/100</span><span class="chip">confidence ${e.confidence_level} (${e.confidence})</span>
    ${d.unit ? `<span class="chip">${esc(d.unit.unit_id)} ${Math.round(d.unit.performance * 100)}% · vib ${d.unit.vibration} mm/s</span>` : ""}</div></div>
    <button class="btn ghost" onclick="closeDrawer()">Close</button></div>
    <h3 style="margin-top:16px">Evidence behind the score</h3>${e.evidence.map(x => `<div class="ev"><span>${esc(x.factor)}<br><small style="color:var(--mute)">${esc(x.reading)}</small></span>
      <div class="b"><i style="width:${x.subscore}%"></i></div><b>+${x.contribution}</b></div>`).join("")}
    ${e.issues.length ? `<h3 style="margin-top:14px">Data-quality issues</h3>${e.issues.map(i => `<div class="alert">${esc(i.detail)}</div>`).join("")}` : ""}
    <h3 style="margin-top:14px">History (last 4 h)</h3>
    ${line(h.map(p => p.inlet_temp), 520, 120, "#f08c3a", "Inlet temperature", "°C")}
    ${line(h.map(p => p.power_kw), 520, 120, "#7c9cff", "Rack power", "kW")}
    ${line(h.map(p => p.gpu_utilisation), 520, 120, "#4cc9f0", "GPU utilisation", "%")}
    <div class="row" style="margin-top:14px"><button class="btn" onclick="investigate('${id}')">Investigate with AI agent</button>
    <a class="btn ghost" style="text-decoration:none;display:inline-block" href="/api/export/incident/${id}">Download report (.md)</a></div>`;
  $("#drawer").hidden = false;
}
function closeDrawer() { $("#drawer").hidden = true; }
$(".drawer-bg").onclick = closeDrawer; document.addEventListener("keydown", e => e.key === "Escape" && closeDrawer());
function investigate(id) { closeDrawer(); show("assistant"); ask(`Why is Rack ${id.slice(1)} overheating?`); }

/* ---------------- workload matching ---------------- */
async function renderPlacement() {
  if (!OV) OV = await api("/api/overview");
  $("#placement").innerHTML = `<h2>Workload-to-Thermal Matching</h2>
  <div class="card"><div class="form">
    <label>Existing workload<select id="pw"><option value="">— new / custom —</option>${OV.workloads.map(w => `<option>${w.workload_id}</option>`).join("")}</select></label>
    <label>GPUs<input id="pg" type="number" value="32" min="1"></label><label>Memory / GPU (GB)<input id="pm" type="number" value="40"></label>
    <label>Heat density<select id="pd"><option>high</option><option selected>medium</option><option>low</option></select></label>
    <label>Priority<select id="pp"><option>critical</option><option>high</option><option selected>normal</option><option>low</option></select></label>
    <label>Deadline (h)<input id="pdl" type="number" value="48"></label><label>Est. runtime (h)<input id="pe" type="number" value="12"></label>
    <label>Scoring profile<select id="pprof"><option value="balanced">balanced</option><option value="thermal_first">thermal-first</option><option value="green">green (adds carbon)</option></select></label>
    <button class="btn" id="pgo">Find best cluster</button></div></div><div id="pres"></div>`;
  $("#pw").onchange = () => { const on = !$("#pw").value; ["pg", "pm", "pd", "pp", "pdl", "pe"].forEach(i => $("#" + i).disabled = !on); };
  $("#pgo").onclick = runPlacement;
}
async function runPlacement() {
  const wl = $("#pw").value;
  const body = { profile: $("#pprof").value };
  if (wl) body.workload_id = wl; else Object.assign(body, { gpu_required: +$("#pg").value, memory_required: +$("#pm").value, density: $("#pd").value, priority: $("#pp").value, deadline_hours: +$("#pdl").value, est_hours: +$("#pe").value });
  $("#pres").innerHTML = `<div class="empty">Calling Compute MCP…</div>`;
  const r = await api("/api/placement", body); if (r.error || r.placement?.error) { $("#pres").innerHTML = `<div class="alert critical">${esc(r.error || r.placement.error)}</div>`; return; }
  const p = r.placement, w = p.weights;
  const legend = Object.keys(w).filter(k => w[k] > 0).map(k => `<span><b style="background:${COL[k]}"></b>${NAMES[k]} (${w[k]})</span>`).join("");
  $("#pres").innerHTML = `<h2>Ranking <small style="color:var(--mute);font-weight:400">· <code>${esc(p.formula)}</code> · hard eligibility checks applied first</small></h2>
   ${p.ranking.length ? p.ranking.map(x => `<div class="rank ${x.rank === 1 ? "best" : ""}"><div class="top"><div><b>#${x.rank} Cluster ${x.cluster_id}</b>
     ${x.is_current ? '<span class="chip warn">current placement</span>' : ""} ${x.rank === 1 ? '<span class="chip good">recommended</span>' : ""}</div>
     <div class="score">${x.score}</div></div>
     <div class="bar">${Object.entries(x.contributions).map(([k, v]) => `<i title="${NAMES[k]}: ${v}" style="width:${v}%;background:${COL[k]}"></i>`).join("")}</div>
     <div class="legend">${legend}</div>
     <div class="meta" style="margin-top:8px"><span class="chip">${x.details.gpus_free} GPUs free</span><span class="chip">thermal headroom ${x.details.thermal_headroom_kw} kW</span>
      <span class="chip">power headroom ${x.details.power_headroom_kw} kW</span><span class="chip">${esc(x.details.cooling_type)}</span><span class="chip">runtime ${x.details.projected_runtime_h} h · slack ×${x.details.deadline_slack}</span>
      <span class="chip">hottest rack ${x.details.max_rack_stress}</span></div>
     <details><summary>Factor scores</summary><table><tr>${Object.keys(x.factors).filter(k => w[k] > 0).map(k => `<th>${NAMES[k]}</th>`).join("")}</tr>
      <tr>${Object.keys(x.factors).filter(k => w[k] > 0).map(k => `<td>${x.factors[k]}</td>`).join("")}</tr></table></details>
     ${!x.is_current && body.workload_id ? `<div style="margin-top:8px"><button class="btn ghost" onclick="simMove('${body.workload_id}','${x.cluster_id}','${body.profile}')">Simulate move to Cluster ${x.cluster_id}</button></div>` : ""}</div>`).join("")
     : `<div class="alert critical">No cluster passes the hard eligibility checks.</div>`}
   ${p.excluded.length ? `<h2>Excluded by hard checks</h2>${p.excluded.map(x => `<div class="excl"><b>Cluster ${x.cluster_id}</b> — ${x.exclusion_reasons.map(esc).join("; ")}</div>`).join("")}` : ""}
   ${p.notes.map(n => `<div class="alert">${esc(n)}</div>`).join("")}
   ${r.resource && !r.resource.error ? `<h2>Resource trade-offs <small style="color:var(--mute);font-weight:400">· synthetic factors, shown not optimised</small></h2><div class="card"><table>
     <tr><th>Cluster</th><th>Runtime</th><th>Energy</th><th>Cost</th><th>Carbon</th><th>Water</th></tr>
     ${r.resource.estimates.map(e => `<tr><td>${e.cluster_id}</td><td>${e.runtime_h} h</td><td>${e.facility_kwh} kWh</td><td>$${e.cost_usd}</td><td>${e.carbon_kg} kg</td><td>${e.water_l} L</td></tr>`).join("")}</table></div>` : ""}
   ${traceHtml(r.trace)}`;
}

/* ---------------- assistant ---------------- */
function traceHtml(t) {
  if (!t || !t.length) return "";
  return `<details open><summary>MCP tool calls (${t.length})</summary><ul class="trace">${t.map(x => `<li class="${x.status}"><span class="srv">${esc(x.server)}</span>.${esc(x.tool)} <small>${esc(JSON.stringify(x.args))}</small> <small>· ${x.ms} ms${x.status === "error" ? " · ERROR" : ""}</small></li>`).join("")}</ul></details>`;
}
async function renderAssistant() {
  const ex = await api("/api/examples");
  $("#assistant").innerHTML = `<h2>AI Operations Assistant</h2><div class="chat"><div class="card">
    <div class="examples">${ex.examples.map(e => `<button>${esc(e)}</button>`).join("")}</div><div id="log"></div>
    <div class="row"><input id="q" placeholder="Ask about racks, workloads, cooling, maintenance…" autocomplete="off"><button class="btn" id="send">Ask</button></div></div>
    <div class="card"><h3>Live MCP trace</h3><div id="livetrace"><div class="empty">Tool calls appear here</div></div>
    <details><summary>Available MCP tools (${ex.tools.length})</summary><table>${ex.tools.map(t => `<tr><td class="srv" style="color:var(--acc)">${esc(t.server)}</td><td>${esc(t.name)}</td></tr>`).join("")}</table></details></div></div>`;
  $(".examples").onclick = e => e.target.tagName === "BUTTON" && ask(e.target.textContent);
  $("#send").onclick = () => { const v = $("#q").value.trim(); if (v) { $("#q").value = ""; ask(v); } };
  $("#q").onkeydown = e => e.key === "Enter" && $("#send").click();
  addMsg("a", "Ask me about the simulated data centre. Every answer is built from real MCP tool calls, shown on the right. Try **Why is Rack 07 overheating?**");
}
function addMsg(who, html) { const d = document.createElement("div"); d.className = "msg " + who; d.innerHTML = html; $("#log").appendChild(d); $("#log").scrollTop = 1e9; return d; }
async function ask(text) {
  if (!$("#log")) await renderAssistant();
  addMsg("u", esc(text));
  const w = addMsg("a", "<i>Planning tool calls…</i>");
  const r = await api("/api/chat", { message: text });
  if (r.error) { w.innerHTML = `<b>Error:</b> ${esc(r.error)}`; return; }
  let extra = "";
  const ap = r.data && r.data.approval;
  if (ap && ap.approval_id) extra += `<div class="row" style="margin-top:8px"><button class="btn ghost" onclick="show('sim')">Review approval ${esc(ap.approval_id)} →</button></div>`;
  if (r.data && r.data.simulation) lastSim = r.data.simulation;
  w.innerHTML = md(r.answer) + extra + `<div class="mono" style="margin-top:6px">${esc(r.mode)}</div>`;
  $("#livetrace").innerHTML = traceHtml(r.trace);
  $("#log").scrollTop = 1e9; refreshBadge();
}

/* ---------------- simulation & approval ---------------- */
async function renderSim() {
  if (!OV) OV = await api("/api/overview");
  const ap = (await api("/api/approvals")).approvals;
  const units = OV.clusters.flatMap(c => c.units);
  $("#sim").innerHTML = `<h2>Incident simulation</h2><div class="grid2"><div>
    <div class="card"><h3>What-if: move a workload</h3><div class="form">
      <label>Workload<select id="sw">${OV.workloads.map(w => `<option>${w.workload_id}</option>`).join("")}</select></label>
      <label>Destination<select id="sd">${OV.clusters.map(c => `<option value="${c.cluster_id}">${esc(c.name)}</option>`).join("")}</select></label>
      <button class="btn" id="smove">Simulate move</button></div>
      <h3 style="margin-top:16px">What-if: cooling unit unavailable</h3><div class="form">
      <label>Cooling unit<select id="su">${units.map(u => `<option>${u.unit_id}</option>`).join("")}</select></label><button class="btn" id="sfail">Simulate failure + evacuation</button></div></div>
    <div id="simres">${lastSim ? simHtml(lastSim) : '<div class="empty card" style="margin-top:12px">Run a simulation to see before/after conditions.</div>'}</div></div>
    <div><h3 style="margin-top:6px">Approval queue &amp; history</h3>${ap.length ? ap.map(a => `<div class="card" style="margin-bottom:10px"><div style="display:flex;justify-content:space-between"><b>${esc(a.approval_id)}</b>
      <span class="status ${a.decision}">${a.decision}</span></div><div style="margin:6px 0">${esc(a.proposed_action)}</div>
      <small style="color:var(--mute)">${esc(a.simulation_id)} · ${esc(a.timestamp)}${a.operator ? " · " + esc(a.operator) : ""}</small>
      ${a.risks.length ? `<ul style="margin:6px 0 6px 16px;padding:0;color:var(--mute);font-size:12px">${a.risks.slice(0, 3).map(r => `<li>${esc(r)}</li>`).join("")}</ul>` : ""}
      ${a.decision === "pending" ? `<div class="row"><input placeholder="Operator name" id="op_${a.approval_id}" value="duty.operator"><input placeholder="Note (optional)" id="nt_${a.approval_id}"></div>
      <div class="row" style="margin-top:8px"><button class="btn ok" ${a.safe_to_apply ? "" : "disabled"} onclick="decide('${a.approval_id}','approved')">Approve (simulated)</button>
      <button class="btn no" onclick="decide('${a.approval_id}','rejected')">Reject</button></div>
      <div class="mono" style="margin-top:6px">No real production workload is moved by this demonstration.</div>` : (a.note ? `<div class="mono">note: ${esc(a.note)}</div>` : "")}</div>`).join("") : '<div class="empty card">No approvals yet.</div>'}</div></div>`;
  $("#smove").onclick = () => simMove($("#sw").value, $("#sd").value);
  $("#sfail").onclick = async () => { const r = await api("/api/simulate", { kind: "cooling_failure", unit_id: $("#su").value }); if (r.error) return toast(r.error); lastSim = r.simulation; $("#simres").innerHTML = simHtml(lastSim); };
}
async function simMove(w, d, profile) {
  show("sim");
  const r = await api("/api/simulate", { kind: "workload_move", workload_id: w, destination_cluster: d, profile: profile || "balanced" });
  if (r.error) return toast(r.error);
  lastSim = r.simulation; $("#simres").innerHTML = simHtml(lastSim);
}
function simHtml(s) {
  let body = "";
  if (s.kind === "workload_move") {
    const rows = [...s.racks.source, ...s.racks.destination];
    body = `<table><tr><th>Rack</th><th>Stress before</th><th>after</th><th>Power kW</th></tr>${rows.map(r => `<tr><td>${r.rack_id}</td><td>${r.before} <small>${r.level_before}</small></td><td><b>${r.after}</b> <small>${r.level_after}</small></td><td>${r.power_before} → ${r.power_after}</td></tr>`).join("")}</table>
    <div class="delta" style="margin-top:10px">${Object.entries(s.clusters).map(([k, c]) => `<div class="card"><b>Cluster ${k}</b><br>thermal headroom ${c.before.thermal_headroom_kw} → <b>${c.after.thermal_headroom_kw} kW</b><br>load ${c.before.load_kw} → ${c.after.load_kw} kW<br>hottest rack ${c.before.max_rack_stress} → ${c.after.max_rack_stress}</div>`).join("")}</div>`;
  } else {
    body = `<p>Racks without cooling: <b>${s.affected_racks.join(", ")}</b> (Cluster ${s.cluster}).</p><table><tr><th>Workload</th><th>Priority</th><th>GPUs</th><th>Proposed destination</th><th>Score</th></tr>
    ${s.moves.map(m => `<tr><td>${m.workload_id}</td><td>${m.priority}</td><td>${m.gpus}</td><td><b>Cluster ${m.to}</b></td><td>${m.score}</td></tr>`).join("")}
    ${s.unplaced.map(u => `<tr><td>${u.workload_id}</td><td>${u.priority}</td><td>${u.gpus}</td><td style="color:var(--critical)">no eligible cluster</td><td>–</td></tr>`).join("")}</table>
    <div class="delta" style="margin-top:10px">${Object.entries(s.clusters_after).map(([k, c]) => `<div class="card"><b>Cluster ${k}</b><br>load ${c.load_kw_before} → ${c.load_kw_after} kW<br>thermal headroom after: ${c.thermal_headroom_after_kw} kW<br>power headroom after: ${c.power_headroom_after_kw} kW</div>`).join("")}</div>`;
  }
  return `<div class="card" style="margin-top:12px"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><b>${esc(s.simulation_id)}</b> · ${esc(s.proposed_action)}</div>
   <span class="chip ${s.safe_to_apply ? "good" : "bad"}">${s.safe_to_apply ? "passes eligibility checks" : "BLOCKED"}</span></div>${body}
   <h3 style="margin-top:12px">Risk considerations</h3><ul style="margin:0 0 0 16px;padding:0;color:var(--mute)">${s.risks.map(r => `<li>${esc(r)}</li>`).join("")}</ul>
   <div class="row" style="margin-top:12px"><button class="btn" ${s.safe_to_apply ? "" : "disabled"} onclick="reqApproval('${s.simulation_id}')">Request operator approval</button></div>
   <div class="mono" style="margin-top:8px">${esc(s.disclaimer)}</div></div>`;
}
async function reqApproval(id) { const r = await api("/api/approval/request", { simulation_id: id }); if (r.error) return toast(r.error); toast("Approval " + r.approval_id + " created — awaiting operator"); renderSim(); refreshBadge(); }
async function decide(id, decision) {
  const r = await api("/api/approval/decide", { approval_id: id, decision, operator: $("#op_" + id).value, note: $("#nt_" + id).value });
  if (r.error) return toast(r.error);
  toast(r.message); lastSim = null; OV = null; renderSim(); refreshBadge();
}
async function refreshBadge() { const o = await api("/api/overview"); OV = o; const pb = $("#pendingBadge"); pb.hidden = !o.kpis.pending_approvals; pb.textContent = o.kpis.pending_approvals; }

/* ---------------- audit ---------------- */
async function loadAudit() {
  const a = await api("/api/audit");
  $("#audit").innerHTML = `<h2>Audit trail <span class="chip ${a.verify.valid ? "good" : "bad"}">${a.verify.valid ? "hash chain valid · " + a.verify.entries + " entries" : "CHAIN BROKEN at #" + a.verify.broken_at}</span></h2>
   <div class="card"><div class="mono" style="margin-bottom:8px">Each entry stores SHA-256(previous hash + event). Editing any past entry breaks the chain and is detected.</div>
   <table><tr><th>#</th><th>Time (UTC)</th><th>Event</th><th>Tool</th><th>Details</th><th>Hash</th></tr>${a.entries.map(e => `<tr><td>${e.log_id}</td><td>${esc(e.timestamp)}</td><td>${esc(e.event_type)}</td><td>${esc(e.tool_name)}</td>
   <td class="mono">${esc(e.details).slice(0, 170)}</td><td class="mono">${esc(e.hash.slice(0, 10))}</td></tr>`).join("")}</table></div>`;
}

/* ---------------- scenario + boot ---------------- */
$("#scenario").onchange = async e => { const r = await api("/api/scenario", { scenario: e.target.value }); toast("Scenario loaded: " + r.description); lastSim = null; OV = null; show(document.querySelector("nav .on").dataset.tab); };
const _show = show; show = function (t) { _show(t); if (t === "placement") renderPlacement(); if (t === "assistant" && !$("#log")) renderAssistant(); };
loadOverview();
