"""Module 1 - Thermal Shadow Intelligence. Pure, deterministic, explainable."""
from .. import db
from ..config import STRESS_RANGES, STRESS_WEIGHTS, STRESS_LEVELS, STALE_AFTER_MIN

def _scale(v, lo, hi):
    return max(0.0, min(100.0, (v - lo) / (hi - lo) * 100.0))

def level_for(score):
    for floor, name in STRESS_LEVELS:
        if score >= floor: return name

def get_history(rack_id, points=12):
    rows = db.q("SELECT * FROM telemetry WHERE rack_id=? ORDER BY timestamp DESC LIMIT ?", (rack_id, points))
    return list(reversed(rows))

def inlet_trend_c_per_hour(hist):
    """Least-squares slope of inlet temperature over the supplied points."""
    if len(hist) < 4: return None
    t0 = db.parse(hist[0]["timestamp"])
    xs = [(db.parse(h["timestamp"]) - t0).total_seconds() / 3600 for h in hist]
    ys = [h["inlet_temp"] for h in hist]
    n = len(xs); mx, my = sum(xs) / n, sum(ys) / n
    den = sum((x - mx) ** 2 for x in xs)
    return None if den == 0 else sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den

def get_rack_context(rack_id):
    rack = db.q("SELECT * FROM racks WHERE rack_id=?", (rack_id,), one=True)
    if not rack: return None
    unit = db.q("SELECT * FROM cooling_units WHERE unit_id=?", (rack["cooling_unit"],), one=True)
    return rack, unit

def data_quality(hist, unit, rack):
    """Return (confidence 0-100, list of issues). Missing/stale/implausible data lowers confidence."""
    issues, conf = [], 100
    if not hist:
        return 0, [{"code": "no_telemetry", "detail": "No telemetry available for this rack"}]
    last = hist[-1]
    age = (db.now() - db.parse(last["timestamp"])).total_seconds() / 60
    if age > STALE_AFTER_MIN:
        conf -= 40; issues.append({"code": "stale", "detail": f"Latest reading is {age:.0f} min old (limit {STALE_AFTER_MIN})"})
    for f in ("gpu_utilisation", "inlet_temp", "outlet_temp", "power_kw"):
        if last.get(f) is None:
            conf -= 25; issues.append({"code": "missing_field", "detail": f"Missing {f}"})
    if last.get("power_kw") is not None and last.get("gpu_utilisation") is not None:
        expected = rack["max_kw"] * (0.15 + 0.65 * last["gpu_utilisation"] / 100)
        if abs(last["power_kw"] - expected) / expected > 0.30:
            conf -= 20; issues.append({"code": "power_util_mismatch",
                "detail": f"Power {last['power_kw']} kW is inconsistent with {last['gpu_utilisation']}% utilisation (expected ~{expected:.0f} kW)"})
    if last.get("outlet_temp") is not None and last.get("inlet_temp") is not None and last["outlet_temp"] < last["inlet_temp"]:
        conf -= 20; issues.append({"code": "negative_delta_t", "detail": "Outlet cooler than inlet - sensor fault likely"})
    if unit is None:
        conf -= 15; issues.append({"code": "no_cooling_unit", "detail": "No cooling-unit telemetry linked"})
    if len(hist) < 6:
        conf -= 10; issues.append({"code": "short_history", "detail": f"Only {len(hist)} historical points"})
    return max(0, conf), issues

def estimate(rack_id, overrides=None, hist_points=12):
    """Thermal-stress estimate for one rack. `overrides` lets the simulator project a changed state."""
    ctx = get_rack_context(rack_id)
    if not ctx: return {"error": f"Unknown rack {rack_id}"}
    rack, unit = ctx
    hist = get_history(rack_id, hist_points)
    conf, issues = data_quality(hist, unit, rack)
    if not hist:
        return {"rack_id": rack_id, "score": None, "level": "Unknown", "confidence": 0, "confidence_level": "Low",
                "issues": issues, "evidence": [], "components": {}}
    last = dict(hist[-1])
    if overrides: last.update(overrides)
    perf = unit["performance"] if unit and unit["status"] != "unavailable" else 0.0
    if overrides and "cooling_perf" in overrides: perf = overrides["cooling_perf"]
    trend = inlet_trend_c_per_hour(hist) if not overrides else (overrides.get("trend") or 0.0)
    raw = {
        "inlet_temp": last["inlet_temp"], "gpu_util": last["gpu_utilisation"],
        "power_load": last["power_kw"] / rack["max_kw"], "cooling_def": 1 - perf,
        "trend": max(0.0, trend or 0.0),
    }
    comp = {k: round(_scale(v, *STRESS_RANGES[k]), 1) for k, v in raw.items()}
    score = round(sum(STRESS_WEIGHTS[k] * comp[k] for k in comp), 1)
    labels = {"inlet_temp": "Inlet temperature", "gpu_util": "GPU utilisation", "power_load": "Rack power load",
              "cooling_def": "Cooling performance deficit", "trend": "Inlet temperature trend"}
    units = {"inlet_temp": f"{raw['inlet_temp']:.1f} C", "gpu_util": f"{raw['gpu_util']:.0f} %",
             "power_load": f"{last['power_kw']:.0f} kW ({raw['power_load']*100:.0f}% of {rack['max_kw']:.0f} kW)",
             "cooling_def": f"unit performance {perf*100:.0f}%", "trend": f"{(trend or 0):+.2f} C/h"}
    evidence = sorted(({"factor": labels[k], "reading": units[k], "subscore": comp[k],
                        "contribution": round(STRESS_WEIGHTS[k] * comp[k], 1)} for k in comp),
                      key=lambda e: -e["contribution"])
    return {"rack_id": rack_id, "cluster_id": rack["cluster_id"], "score": score, "level": level_for(score),
            "confidence": conf, "confidence_level": "High" if conf >= 80 else "Medium" if conf >= 50 else "Low",
            "issues": issues, "evidence": evidence, "components": comp, "raw": {k: round(v, 3) for k, v in raw.items()},
            "reading_time": last["timestamp"], "delta_t": round(last["outlet_temp"] - last["inlet_temp"], 1)}

def rank_all():
    out = [estimate(r["rack_id"]) for r in db.q("SELECT rack_id FROM racks")]
    return sorted(out, key=lambda e: -(e["score"] if e["score"] is not None else -1))

def alerts():
    """Alerts for stress levels and data-quality problems, each with evidence + next steps."""
    res = []
    for e in rank_all():
        if e["score"] is not None and e["score"] >= 55:
            top = e["evidence"][:3]
            res.append({"rack_id": e["rack_id"], "severity": "critical" if e["level"] == "Critical" else "warning",
                        "type": "thermal_stress", "message": f"{e['rack_id']} thermal stress {e['score']}/100 ({e['level']})",
                        "evidence": [f"{x['factor']}: {x['reading']}" for x in top], "confidence": e["confidence_level"],
                        "next_steps": ["Run cooling investigation", "Check placement alternatives for affected workloads"]})
        for iss in e["issues"]:
            res.append({"rack_id": e["rack_id"], "severity": "warning", "type": "data_quality",
                        "message": f"{e['rack_id']}: {iss['detail']}", "evidence": [iss["code"]],
                        "confidence": e["confidence_level"], "next_steps": ["Verify sensor/telemetry pipeline before trusting this rack's score"]})
    return res

def cluster_summary(cluster_id):
    """Cooling headroom view of a cluster from latest telemetry + cooling-unit state."""
    cl = db.q("SELECT * FROM clusters WHERE cluster_id=?", (cluster_id,), one=True)
    racks = [estimate(r["rack_id"]) for r in db.q("SELECT rack_id FROM racks WHERE cluster_id=?", (cluster_id,))]
    units = db.q("SELECT * FROM cooling_units WHERE cluster_id=?", (cluster_id,))
    load = 0.0
    for r in db.q("SELECT rack_id FROM racks WHERE cluster_id=?", (cluster_id,)):
        h = get_history(r["rack_id"], 1)
        if h and h[-1]["power_kw"] is not None: load += h[-1]["power_kw"]
    eff_cool = sum(u["capacity_kw"] * (u["performance"] if u["status"] != "unavailable" else 0) for u in units)
    scores = [r["score"] for r in racks if r["score"] is not None]
    return {"cluster_id": cluster_id, "load_kw": round(load, 1), "effective_cooling_kw": round(eff_cool, 1),
            "thermal_headroom_kw": round(eff_cool - load, 1),
            "max_rack_stress": max(scores) if scores else None,
            "mean_rack_stress": round(sum(scores) / len(scores), 1) if scores else None,
            "power_cap_kw": cl["power_cap_kw"], "power_headroom_kw": round(cl["power_cap_kw"] - load, 1),
            "min_confidence": min((r["confidence"] for r in racks), default=0)}
