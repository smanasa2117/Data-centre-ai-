"""Module 4 - what-if simulation. NOTHING here touches real equipment; 'applying' only edits the simulated DB."""
import json, uuid, copy
from .. import db
from . import thermal_engine as te, workload_matcher as wm

def _sid(prefix): return f"{prefix}-{uuid.uuid4().hex[:6].upper()}"

def _rack_override(rack, last, d_kw):
    """Project a rack after a power change of d_kw (same physical model used by the seed data)."""
    new_p = max(rack["max_kw"] * 0.12, last["power_kw"] + d_kw)
    util = max(3.0, min(99.0, (new_p / rack["max_kw"] - 0.15) / 0.65 * 100))
    d_inlet = 4 * (new_p - last["power_kw"]) / rack["max_kw"]
    inlet = last["inlet_temp"] + d_inlet
    outlet = inlet + 6 + 22 * (new_p / rack["max_kw"])
    return {"gpu_utilisation": round(util, 1), "power_kw": round(new_p, 1), "inlet_temp": round(inlet, 2),
            "outlet_temp": round(outlet, 2), "trend": 0.0}

def _rack_state(rack_id, d_kw=0.0):
    rack = db.q("SELECT * FROM racks WHERE rack_id=?", (rack_id,), one=True)
    last = te.get_history(rack_id, 1)[0]
    before = te.estimate(rack_id)
    ov = _rack_override(rack, last, d_kw) if d_kw else None
    after = te.estimate(rack_id, overrides=ov) if ov else before
    return {"rack_id": rack_id, "before": before["score"], "after": after["score"], "level_before": before["level"],
            "level_after": after["level"], "power_before": last["power_kw"],
            "power_after": ov["power_kw"] if ov else last["power_kw"], "override": ov}

def simulate_move(workload_id, dest_cluster, incident_id=None, profile="balanced"):
    w = db.q("SELECT * FROM workloads WHERE workload_id=?", (workload_id,), one=True)
    if not w: return {"error": f"Unknown workload {workload_id}"}
    dest = db.q("SELECT * FROM clusters WHERE cluster_id=?", (dest_cluster,), one=True)
    if not dest: return {"error": f"Unknown cluster {dest_cluster}"}
    if w["cluster_id"] == dest_cluster: return {"error": "Workload is already on that cluster"}
    spec = wm.load_spec(workload_id)
    ev = wm.evaluate_cluster(dest, spec, profile)
    src_ev = wm.evaluate_cluster(db.q("SELECT * FROM clusters WHERE cluster_id=?", (w["cluster_id"],), one=True), spec, profile)
    add_kw = ev["details"]["est_added_kw"]
    src_racks = [_rack_state(w["rack_id"], -w["power_kw"])]
    dest_rack_ids = [r["rack_id"] for r in db.q("SELECT rack_id FROM racks WHERE cluster_id=?", (dest_cluster,))]
    # spread the added heat over the destination's racks in proportion to their free power
    free = {}
    for rid in dest_rack_ids:
        rk = db.q("SELECT * FROM racks WHERE rack_id=?", (rid,), one=True)
        free[rid] = max(1.0, rk["max_kw"] - te.get_history(rid, 1)[0]["power_kw"])
    tot = sum(free.values())
    dst_racks = [_rack_state(rid, add_kw * free[rid] / tot) for rid in dest_rack_ids]
    sb, sa = te.cluster_summary(w["cluster_id"]), te.cluster_summary(dest_cluster)
    changed = {w["cluster_id"]: src_racks, dest_cluster: dst_racks}
    risks = ["Destination capacity must be validated at execution time.", "Workload compatibility must be checked by an engineer.",
             "The simulated result is an estimate, not a guarantee of real-world performance."]
    if not ev["eligible"]: risks.insert(0, "BLOCKED: destination fails hard eligibility checks: " + "; ".join(ev["exclusion_reasons"]))
    if ev["details"]["data_confidence"] < 80: risks.append("Destination telemetry has reduced confidence.")
    max_after_dst = max(r["after"] for r in dst_racks if r["after"] is not None)
    if max_after_dst >= 50: risks.append(f"Destination hottest rack would reach {max_after_dst} (>= Elevated).")
    result = {
        "kind": "workload_move", "workload_id": workload_id, "from": w["cluster_id"], "to": dest_cluster,
        "moves": [{"workload_id": workload_id, "from": w["cluster_id"], "to": dest_cluster, "from_rack": w["rack_id"],
                   "gpus": w["gpu_required"], "power_kw": w["power_kw"], "priority": w["priority"]}],
        "destination_check": ev, "source_check": {"score": src_ev["score"], "factors": src_ev["factors"]},
        "racks": {"source": [{k: v for k, v in r.items() if k != "override"} for r in src_racks],
                  "destination": [{k: v for k, v in r.items() if k != "override"} for r in dst_racks]},
        "clusters": {
            w["cluster_id"]: {"before": {"load_kw": sb["load_kw"], "thermal_headroom_kw": sb["thermal_headroom_kw"], "max_rack_stress": sb["max_rack_stress"]},
                              "after": {"load_kw": round(sb["load_kw"] - w["power_kw"], 1), "thermal_headroom_kw": round(sb["thermal_headroom_kw"] + w["power_kw"], 1),
                                        "max_rack_stress": max(r["after"] for r in te_rank_cluster(w["cluster_id"], src_racks))}},
            dest_cluster: {"before": {"load_kw": sa["load_kw"], "thermal_headroom_kw": sa["thermal_headroom_kw"], "max_rack_stress": sa["max_rack_stress"]},
                           "after": {"load_kw": round(sa["load_kw"] + add_kw, 1), "thermal_headroom_kw": round(sa["thermal_headroom_kw"] - add_kw, 1),
                                     "max_rack_stress": max_after_dst}}},
        "risks": risks, "safe_to_apply": ev["eligible"],
        "telemetry_after": {r["rack_id"]: r["override"] for r in src_racks + dst_racks if r["override"]},
        "disclaimer": "Simulated estimate. No real workload is moved."}
    return _store(result, incident_id, f"Move simulated workload {workload_id} from Cluster {w['cluster_id']} to Cluster {dest_cluster}")

def te_rank_cluster(cluster_id, changed):
    """Stress of every rack in a cluster, substituting projected values where available."""
    ch = {r["rack_id"]: r for r in changed}
    out = []
    for r in db.q("SELECT rack_id FROM racks WHERE cluster_id=?", (cluster_id,)):
        out.append({"rack_id": r["rack_id"], "after": ch[r["rack_id"]]["after"] if r["rack_id"] in ch else te.estimate(r["rack_id"])["score"]})
    return out

def simulate_cooling_failure(unit_id, incident_id=None, profile="balanced"):
    u = db.q("SELECT * FROM cooling_units WHERE unit_id=?", (unit_id,), one=True)
    if not u: return {"error": f"Unknown cooling unit {unit_id}"}
    cid = u["cluster_id"]
    racks = [r["rack_id"] for r in db.q("SELECT rack_id FROM racks WHERE cooling_unit=?", (unit_id,))]
    wls = db.q("SELECT * FROM workloads WHERE cluster_id=? AND status='running'", (cid,))
    order = {"critical": 0, "high": 1, "normal": 2, "low": 3}
    wls.sort(key=lambda w: (order.get(w["priority"], 9), w["deadline_hours"]))
    clusters = db.q("SELECT * FROM clusters")
    for c in clusters:
        if c["cluster_id"] == cid: c["status"] = "cooling_unavailable"
    sums = {c["cluster_id"]: te.cluster_summary(c["cluster_id"]) for c in clusters}
    before = copy.deepcopy(sums)
    plan, unplaced = [], []
    for w in wls:                                   # highest priority first, sequentially updating a virtual state
        spec = wm.load_spec(w["workload_id"]); spec["current_cluster"] = None
        r = wm.find_suitable_cluster(spec, profile, exclude=cid, clusters=clusters, sums=sums)
        if not r["recommended"]:
            unplaced.append({"workload_id": w["workload_id"], "priority": w["priority"], "gpus": w["gpu_required"],
                             "reasons": {x["cluster_id"]: x["exclusion_reasons"] for x in r["excluded"]}}); continue
        best = r["ranking"][0]; d = best["cluster_id"]; kw = best["details"]["est_added_kw"]
        for c in clusters:
            if c["cluster_id"] == d: c["available_gpus"] -= w["gpu_required"]
        sums[d]["power_headroom_kw"] -= kw * 1.0; sums[d]["thermal_headroom_kw"] -= kw
        sums[d]["load_kw"] += kw
        plan.append({"workload_id": w["workload_id"], "priority": w["priority"], "from": cid, "to": d, "gpus": w["gpu_required"],
                     "power_kw": w["power_kw"], "est_added_kw": kw, "score": best["score"], "from_rack": w["rack_id"],
                     "alternatives": [{"cluster_id": x["cluster_id"], "score": x["score"]} for x in r["ranking"][1:]]})
    touched = sorted({p["to"] for p in plan})
    result = {"kind": "cooling_failure", "unit_id": unit_id, "cluster": cid, "affected_racks": racks,
              "affected_workloads": [{"workload_id": w["workload_id"], "priority": w["priority"], "gpus": w["gpu_required"], "rack": w["rack_id"]} for w in wls],
              "moves": plan, "unplaced": unplaced,
              "clusters_after": {d: {"load_kw_before": before[d]["load_kw"], "load_kw_after": round(sums[d]["load_kw"], 1),
                                     "thermal_headroom_after_kw": round(sums[d]["thermal_headroom_kw"], 1),
                                     "power_headroom_after_kw": round(sums[d]["power_headroom_kw"], 1)} for d in touched},
              "risks": (["%d workload(s) could not be re-placed and would need to be paused or queued: %s" % (len(unplaced), ", ".join(u_["workload_id"] for u_ in unplaced))] if unplaced else []) +
                       ["Plan is greedy by priority; engineer review is required.", "Simulated estimate, not a guarantee."],
              "safe_to_apply": bool(plan), "disclaimer": "Simulated estimate. No real workload is moved and no cooling equipment is controlled.",
              "telemetry_after": {}}
    return _store(result, incident_id, f"Evacuate {len(plan)} workload(s) from Cluster {cid} after simulated loss of {unit_id}")

def _store(result, incident_id, action):
    sid = _sid("SIM")
    db.run("INSERT INTO simulations VALUES(?,?,?,?,?)", (sid, incident_id, action, json.dumps(result), db.iso(db.now())))
    db.audit("simulation_created", "simulate_incident", {"simulation_id": sid, "action": action, "safe": result.get("safe_to_apply")})
    result["simulation_id"], result["proposed_action"] = sid, action
    return result

# ---------------------------------------------------------------- approval
def request_approval(simulation_id):
    sim = db.q("SELECT * FROM simulations WHERE simulation_id=?", (simulation_id,), one=True)
    if not sim: return {"error": f"Unknown simulation {simulation_id}"}
    res = json.loads(sim["result"])
    aid = _sid("APR")
    db.run("INSERT INTO approvals VALUES(?,?,?,?,?,?)", (aid, simulation_id, "pending", None, None, db.iso(db.now())))
    db.audit("approval_requested", "request_operator_approval", {"approval_id": aid, "simulation_id": simulation_id})
    return {"approval_id": aid, "status": "awaiting_operator_decision", "proposed_action": sim["proposed_action"],
            "risks": res.get("risks", []), "safe_to_apply": res.get("safe_to_apply"),
            "notice": "Prototype approval. No real production workload is moved."}

def record_decision(approval_id, decision, operator="operator", note=""):
    decision = decision.lower()
    if decision not in ("approved", "rejected"): return {"error": "decision must be 'approved' or 'rejected'"}
    ap = db.q("SELECT * FROM approvals WHERE approval_id=?", (approval_id,), one=True)
    if not ap: return {"error": f"Unknown approval {approval_id}"}
    if ap["decision"] != "pending": return {"error": f"Approval already {ap['decision']}"}
    sim = db.q("SELECT * FROM simulations WHERE simulation_id=?", (ap["simulation_id"],), one=True)
    res = json.loads(sim["result"])
    applied = []
    if decision == "approved":
        if not res.get("safe_to_apply"):
            return {"error": "Blocked: simulation is not safe to apply (hard eligibility check failed).", "risks": res.get("risks")}
        # re-validate destinations against the CURRENT state before applying
        for m in res["moves"]:
            w = db.q("SELECT * FROM workloads WHERE workload_id=?", (m["workload_id"],), one=True)
            if w["cluster_id"] != m["from"]: return {"error": f"State changed: {m['workload_id']} is no longer on Cluster {m['from']}. Re-run the simulation."}
            dest = db.q("SELECT * FROM clusters WHERE cluster_id=?", (m["to"],), one=True)
            if res["kind"] == "workload_move":
                chk = wm.evaluate_cluster(dest, wm.load_spec(m["workload_id"]))
                if not chk["eligible"]: return {"error": "Blocked at execution: " + "; ".join(chk["exclusion_reasons"])}
        applied = _apply(res)
    db.run("UPDATE approvals SET decision=?,operator=?,note=?,timestamp=? WHERE approval_id=?",
           (decision, operator, note, db.iso(db.now()), approval_id))
    db.audit("operator_decision", "record_approved_action",
             {"approval_id": approval_id, "simulation_id": ap["simulation_id"], "decision": decision, "operator": operator,
              "note": note, "applied_to_simulation": applied, "incident_id": sim["incident_id"]})
    return {"approval_id": approval_id, "decision": decision, "operator": operator, "applied_to_simulation": applied,
            "message": ("Approved. Simulated state updated (no real equipment touched)." if decision == "approved"
                        else "Rejected. Recorded in the audit trail; nothing was executed.")}

def _apply(res):
    from ..seed import recompute_clusters
    applied = []
    for m in res["moves"]:
        dest_racks = [r["rack_id"] for r in db.q("SELECT rack_id FROM racks WHERE cluster_id=?", (m["to"],))]
        target = min(dest_racks, key=lambda r: te.estimate(r)["score"] or 0)
        db.run("UPDATE workloads SET cluster_id=?,rack_id=? WHERE workload_id=?", (m["to"], target, m["workload_id"]))
        applied.append({"workload_id": m["workload_id"], "to_cluster": m["to"], "to_rack": target})
    # write fresh (projected) telemetry so dashboards reflect the simulated outcome
    ts = db.iso(db.now())
    for rid, ov in (res.get("telemetry_after") or {}).items():
        db.run("INSERT INTO telemetry(rack_id,gpu_utilisation,inlet_temp,outlet_temp,power_kw,timestamp) VALUES(?,?,?,?,?,?)",
               (rid, ov["gpu_utilisation"], ov["inlet_temp"], ov["outlet_temp"], ov["power_kw"], ts))
    recompute_clusters()
    return applied
