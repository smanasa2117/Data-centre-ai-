"""Energy / carbon / water estimates (ILLUSTRATIVE factors - not measured facility data)."""
from .. import db
from ..config import TARIFF_PER_KWH
from . import thermal_engine as te

WUE = {"air_crah": 1.8, "rear_door_hx": 1.2, "direct_liquid": 0.4, "hybrid": 0.9}   # litres per kWh IT, synthetic

def energy_metrics(cluster_id=None):
    out = []
    for c in db.q("SELECT * FROM clusters" + (" WHERE cluster_id=?" if cluster_id else ""), (cluster_id,) if cluster_id else ()):
        sm = te.cluster_summary(c["cluster_id"])
        fac_kw = sm["load_kw"] * c["pue"]
        out.append({"cluster_id": c["cluster_id"], "it_load_kw": sm["load_kw"], "pue": c["pue"], "facility_kw": round(fac_kw, 1),
                    "cost_per_hour_usd": round(fac_kw * TARIFF_PER_KWH, 2),
                    "carbon_kg_per_hour": round(fac_kw * c["carbon_g_kwh"] / 1000, 1),
                    "water_l_per_hour": round(sm["load_kw"] * WUE[c["cooling_type"]]),
                    "carbon_intensity_g_kwh": c["carbon_g_kwh"], "power_headroom_kw": sm["power_headroom_kw"]})
    return out

def compare_costs(spec):
    """Estimated resource cost of running the workload to completion on each cluster."""
    rows = []
    for c in db.q("SELECT * FROM clusters"):
        kw = spec["gpu_required"] * c["kw_per_gpu"] * (0.9 if spec.get("density") == "low" else 1.0)
        hours = spec["est_hours"] / c["speed_factor"]
        kwh = kw * hours * c["pue"]
        rows.append({"cluster_id": c["cluster_id"], "runtime_h": round(hours, 1), "facility_kwh": round(kwh),
                     "cost_usd": round(kwh * TARIFF_PER_KWH), "carbon_kg": round(kwh * c["carbon_g_kwh"] / 1000),
                     "water_l": round(kw * hours * WUE[c["cooling_type"]])})
    best = {k: min(rows, key=lambda r: r[k])["cluster_id"] for k in ("cost_usd", "carbon_kg", "water_l", "runtime_h")}
    return {"workload": spec.get("workload_id"), "estimates": rows, "lowest": best,
            "note": "Trade-offs are shown, not optimised: the lowest-carbon cluster is not always the safest or fastest."}
