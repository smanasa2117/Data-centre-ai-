"""Module 2 - Workload-to-Thermal Matching.
Transparent weighted scoring + HARD eligibility checks. The LLM never ranks clusters."""
from .. import db
from ..config import PROFILES, POWER_SAFETY_MARGIN
from . import thermal_engine as te

# cooling compatibility (0-100) by workload heat density and cluster cooling type
COOLING_COMPAT = {
    "high":   {"direct_liquid": 100, "hybrid": 90, "rear_door_hx": 65, "air_crah": 10},
    "medium": {"direct_liquid": 85, "hybrid": 90, "rear_door_hx": 90, "air_crah": 60},
    "low":    {"direct_liquid": 70, "hybrid": 85, "rear_door_hx": 90, "air_crah": 95},
}
HARD_COMPAT_FLOOR = 20
# hardware families a workload's required architecture can run on
ARCH_OK = {"H100": ("H100", "H200"), "H200": ("H200",), "A100": ("A100", "H100", "H200")}

def _clamp(x, lo=0.0, hi=100.0): return max(lo, min(hi, x))

def load_spec(workload_id=None, spec=None):
    """Resolve a workload spec from DB id or an ad-hoc dict (new submission)."""
    if workload_id:
        w = db.q("SELECT * FROM workloads WHERE workload_id=?", (workload_id,), one=True)
        if not w: return None
        return {"workload_id": w["workload_id"], "gpu_required": w["gpu_required"], "memory_required": w["memory_required"],
                "priority": w["priority"], "deadline_hours": w["deadline_hours"], "est_hours": w["est_hours"],
                "density": w["density"], "arch": w["arch"], "current_cluster": w["cluster_id"], "status": w["status"]}
    s = dict(spec or {})
    s.setdefault("workload_id", "NEW-WORKLOAD"); s.setdefault("priority", "normal"); s.setdefault("density", "medium")
    s.setdefault("arch", "any"); s.setdefault("deadline_hours", 48); s.setdefault("est_hours", 10); s.setdefault("current_cluster", None)
    for k in ("gpu_required", "memory_required"):
        if k not in s: raise ValueError(f"missing {k}")
    s["gpu_required"] = int(s["gpu_required"]); s["memory_required"] = float(s["memory_required"])
    s["deadline_hours"] = float(s["deadline_hours"]); s["est_hours"] = float(s["est_hours"])
    return s

def evaluate_cluster(cl, spec, profile="balanced", summaries=None, carbon_range=None):
    cid = cl["cluster_id"]
    cur = spec.get("current_cluster") == cid
    sm = (summaries or {}).get(cid) or te.cluster_summary(cid)
    est_kw = spec["gpu_required"] * cl["kw_per_gpu"] * (0.9 if spec["density"] == "low" else 1.0)
    add_kw = 0.0 if cur else est_kw                      # already counted in telemetry when current
    avail = cl["available_gpus"] + (spec["gpu_required"] if cur else 0)
    reasons = []
    # ---- hard eligibility checks (a high score can never override these) ----
    if cl["status"] != "online": reasons.append(f"cluster {cl['status']}")
    if not cur and avail < spec["gpu_required"]:
        reasons.append(f"insufficient GPUs ({avail} free, {spec['gpu_required']} needed)")
    if cl["gpu_mem_gb"] < spec["memory_required"]:
        reasons.append(f"GPU memory too small ({cl['gpu_mem_gb']} GB < {spec['memory_required']:.0f} GB per GPU)")
    if spec["arch"] not in ("any", None) and not any(a in cl["gpu_model"] for a in ARCH_OK.get(spec["arch"], (spec["arch"],))):
        reasons.append(f"incompatible hardware (needs {spec['arch']}, cluster has {cl['gpu_model']})")
    compat = COOLING_COMPAT[spec["density"]][cl["cooling_type"]]
    if compat < HARD_COMPAT_FLOOR and not cur:
        reasons.append(f"cooling incompatible ({spec['density']}-density load on {cl['cooling_type']})")
    p_head = sm["power_headroom_kw"] - add_kw * POWER_SAFETY_MARGIN
    if not cur and p_head < 0:
        reasons.append(f"insufficient power ({sm['power_headroom_kw']:.0f} kW free, ~{add_kw*POWER_SAFETY_MARGIN:.0f} kW needed incl. margin)")
    t_head_kw = sm["thermal_headroom_kw"] - add_kw
    if not cur and t_head_kw < 0:
        reasons.append(f"insufficient cooling capacity ({sm['thermal_headroom_kw']:.0f} kW free, ~{add_kw:.0f} kW needed)")
    runtime = spec["est_hours"] / cl["speed_factor"]
    slack = spec["deadline_hours"] / runtime if runtime else 9.9
    if slack < 1.0: reasons.append(f"cannot meet deadline (needs {runtime:.0f} h, has {spec['deadline_hours']:.0f} h)")

    # ---- soft factors, each normalised to 0-100 ----
    G = _clamp(100 * avail / (spec["gpu_required"] * 2))
    eff = max(sm["effective_cooling_kw"], 1)
    t_frac = t_head_kw / eff
    mx = sm["max_rack_stress"] if sm["max_rack_stress"] is not None else 50
    T = _clamp(0.6 * _clamp(t_frac / 0.40 * 100) + 0.4 * (100 - mx))
    P = _clamp(p_head / cl["power_cap_kw"] / 0.35 * 100) if not cur else _clamp((sm["power_headroom_kw"]) / cl["power_cap_kw"] / 0.35 * 100)
    C = float(compat)
    slack_score = _clamp((slack - 1.0) / 0.5 * 100)
    prio_fit = (100 - mx) if spec["priority"] in ("critical", "high") else 80
    D = 0.7 * slack_score + 0.3 * prio_fit
    cr = carbon_range or (0, 1000)
    E = _clamp(100 * (1 - (cl["carbon_g_kwh"] * cl["pue"]) / 900))
    w = PROFILES[profile]
    S = w["G"] * G + w["T"] * T + w["P"] * P + w["C"] * C + w["D"] * D + w["E"] * E
    parts = {"G": G, "T": T, "P": P, "C": C, "D": D, "E": E}
    return {"cluster_id": cid, "name": cl["name"], "is_current": cur, "eligible": not reasons,
            "exclusion_reasons": reasons, "score": round(S, 1),
            "factors": {k: round(v, 1) for k, v in parts.items()},
            "contributions": {k: round(w[k] * parts[k], 1) for k in parts if w[k] > 0},
            "details": {"gpus_free": avail, "est_added_kw": round(add_kw, 1), "thermal_headroom_kw": round(sm["thermal_headroom_kw"], 1),
                        "power_headroom_kw": round(sm["power_headroom_kw"], 1), "max_rack_stress": sm["max_rack_stress"],
                        "cooling_type": cl["cooling_type"], "projected_runtime_h": round(runtime, 1),
                        "deadline_slack": round(slack, 2), "data_confidence": sm["min_confidence"]}}

def find_suitable_cluster(spec, profile="balanced", exclude=None, clusters=None, sums=None):
    """`clusters`/`sums` may be supplied by the simulator to rank against a virtual (what-if) state."""
    if profile not in PROFILES: raise ValueError(f"unknown profile {profile}; use {list(PROFILES)}")
    clusters = clusters or db.q("SELECT * FROM clusters")
    sums = sums or {c["cluster_id"]: te.cluster_summary(c["cluster_id"]) for c in clusters}
    res = [evaluate_cluster(c, spec, profile, sums) for c in clusters if c["cluster_id"] != exclude]
    elig = sorted([r for r in res if r["eligible"]], key=lambda r: (-r["score"], r["cluster_id"]))
    exc = [r for r in res if not r["eligible"]]
    for i, r in enumerate(elig, 1): r["rank"] = i
    notes = []
    if any(r["details"]["data_confidence"] < 80 for r in elig):
        notes.append("Some candidate clusters rely on low-confidence telemetry; treat the ranking as uncertain.")
    return {"workload": spec, "profile": profile, "weights": PROFILES[profile], "ranking": elig, "excluded": exc,
            "recommended": elig[0]["cluster_id"] if elig else None, "notes": notes,
            "formula": "S = " + " + ".join(f"{v:.2f}{k}" for k, v in PROFILES[profile].items() if v)}
