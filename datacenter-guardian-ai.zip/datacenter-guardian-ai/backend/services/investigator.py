"""Module 3 - Cooling Failure Investigator.
Builds an evidence-based report from tool results. It proposes POSSIBLE contributing factors and separates
observed evidence from unverified causes. It never claims a confirmed mechanical failure."""
import datetime as dt
from .. import db

def derive_tags(est, unit, maint, hist):
    raw, tags = est.get("raw", {}), []
    if raw.get("gpu_util", 0) >= 85: tags.append("high_util")
    if unit and unit["performance"] < 0.80: tags.append("cooling_perf_drop")
    if unit and unit["vibration"] > 4.5: tags.append("vibration_high")
    if any(_days_ago(m["date"]) <= 14 for m in maint): tags.append("recent_maintenance")
    if raw.get("trend", 0) >= 1.0 and raw.get("gpu_util", 0) >= 70: tags.append("workload_ramp")
    if any(i["code"] in ("power_util_mismatch", "negative_delta_t") for i in est.get("issues", [])): tags.append("sensor_mismatch")
    if any(i["code"] == "stale" for i in est.get("issues", [])): tags.append("stale_or_noisy")
    if est.get("delta_t") is not None and est["delta_t"] < 10 and raw.get("power_load", 0) > 0.5: tags.append("low_delta_t")
    if raw.get("inlet_temp", 0) >= 27: tags.append("high_inlet")
    return tags

def _days_ago(datestr):
    return (db.now().date() - dt.date.fromisoformat(datestr)).days

def jaccard(a, b):
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if a | b else 0.0

def similar_incidents(tags, limit=3):
    out = []
    for i in db.q("SELECT * FROM incidents WHERE status='closed'"):
        sim = jaccard(tags, i["signature"].split(","))
        if sim > 0: out.append({**i, "similarity": round(sim, 2), "shared_tags": sorted(set(tags) & set(i["signature"].split(",")))})
    return sorted(out, key=lambda x: -x["similarity"])[:limit]

def _support(points):
    return "Strong" if points >= 60 else "Moderate" if points >= 35 else "Weak" if points >= 15 else "Not supported"

def build_report(rack_id, est, workloads, unit, maint, similar, hist):
    raw = est.get("raw", {})
    obs = []
    obs.append({"fact": f"Thermal stress {est['score']}/100 ({est['level']}), confidence {est['confidence_level']}", "source": "Thermal MCP: estimate_thermal_stress"})
    obs.append({"fact": f"GPU utilisation {raw['gpu_util']:.0f}%, rack power {raw['power_load']*100:.0f}% of rated, inlet {raw['inlet_temp']:.1f} C, delta-T {est['delta_t']} C", "source": "Thermal MCP: get_rack_telemetry"})
    obs.append({"fact": f"Inlet temperature trend {raw['trend']:+.2f} C/h over the last hour", "source": "Thermal MCP: get_rack_telemetry"})
    if workloads: obs.append({"fact": "Running on this rack: " + ", ".join(f"{w['workload_id']} ({w['gpu_required']} GPUs, {w['priority']})" for w in workloads), "source": "Compute MCP: get_workload_status"})
    if unit:
        obs.append({"fact": f"Cooling unit {unit['unit_id']} status '{unit['status']}', performance {unit['performance']*100:.0f}%, vibration {unit['vibration']:.1f} mm/s", "source": "Maintenance MCP: get_cooling_unit_status"})
    recent = [m for m in maint if _days_ago(m["date"]) <= 30]
    for m in recent: obs.append({"fact": f"Maintenance {m['record_id']} on {m['date']} ({_days_ago(m['date'])} days ago): {m['description']}", "source": "Maintenance MCP: get_equipment_history"})

    perf = unit["performance"] if unit else None
    hyps = []
    # H1 workload heat
    pts, f, a = 0, [], []
    if raw["gpu_util"] >= 85: pts += 30; f.append(f"GPU utilisation is high ({raw['gpu_util']:.0f}%)")
    if raw["power_load"] >= 0.70: pts += 25; f.append(f"Rack power is {raw['power_load']*100:.0f}% of rated")
    if raw["trend"] >= 1.0: pts += 15; f.append("Inlet temperature is rising while load ramps up")
    if perf is not None and perf >= 0.85: pts += 25; f.append("Cooling unit performance looks normal, so load alone could explain the heat")
    elif perf is not None: a.append(f"Cooling performance is reduced ({perf*100:.0f}%), so load is unlikely to be the only factor")
    hyps.append({"factor": "Increased workload heat generation", "points": pts, "supporting": f, "against": a,
                 "verify": ["Compare rack power against the job's expected draw", "Check whether the job recently scaled up"]})
    # H2 reduced cooling performance
    pts, f, a = 0, [], []
    if perf is not None and perf < 0.80: pts += 40 if perf >= 0.70 else 50; f.append(f"Cooling unit performance is {perf*100:.0f}% (below 80%)")
    if unit and unit["vibration"] > 4.5: pts += 20; f.append(f"Vibration {unit['vibration']:.1f} mm/s exceeds the 4.5 mm/s prototype watch level")
    if unit and unit["status"] == "degraded": pts += 15; f.append("Unit is reporting a degraded status")
    if raw["cooling_def"] > 0.25 and raw["inlet_temp"] >= 26: pts += 10; f.append("Inlet temperature is elevated alongside the deficit")
    if perf is not None and perf >= 0.85: a.append("Unit performance is normal")
    hyps.append({"factor": "Reduced cooling performance", "points": pts, "supporting": f, "against": a,
                 "verify": ["Verify the cooling-unit readings on site", "Inspect pump/fan assemblies and heat-exchanger coupling"]})
    # H3 maintenance related
    pts, f, a = 0, [], []
    rm = [m for m in maint if _days_ago(m["date"]) <= 14]
    if rm and perf is not None and perf < 0.85: pts += 55; f.append(f"Cooling degradation follows maintenance {rm[0]['record_id']} ({_days_ago(rm[0]['date'])} days ago)")
    elif rm: pts += 15; f.append("A recent maintenance record exists but no clear performance drop")
    top = similar[0] if similar else None
    if top and "recent_maintenance" in top["shared_tags"] and top["similarity"] >= 0.4: pts += 20; f.append(f"{top['incident_id']} had a similar pattern (similarity {top['similarity']}): {top['resolution']}")
    if not rm: a.append("No maintenance in the last 14 days")
    hyps.append({"factor": "Issue introduced by recent maintenance", "points": pts, "supporting": f, "against": a,
                 "verify": ["Review work order for the recent service", "Check re-assembly (couplings, fan seating, calibration)"]})
    # H4 sensor / airflow
    pts, f, a = 0, [], []
    for i in est["issues"]: pts += 30; f.append(i["detail"])
    if est["delta_t"] is not None and est["delta_t"] < 10 and raw["power_load"] > 0.5: pts += 30; f.append(f"Low delta-T ({est['delta_t']} C) at high power may indicate bypass/recirculation")
    if not est["issues"]: a.append("Telemetry is fresh and internally consistent")
    hyps.append({"factor": "Sensor fault or airflow issue", "points": pts, "supporting": f, "against": a,
                 "verify": ["Cross-check with a handheld thermometer", "Inspect blanking panels and containment"]})
    for h in hyps:
        if h["against"]: h["points"] = min(h["points"], 55)   # contradicting evidence caps the support level
        h["support"] = _support(h["points"])
    hyps.sort(key=lambda h: -h["points"])
    ranked = [h for h in hyps if h["points"] >= 15]

    gaps = []
    if est["confidence"] < 80: gaps.append("Telemetry confidence is reduced; conclusions are less certain.")
    if not unit: gaps.append("No cooling-unit telemetry linked to this rack.")
    gaps.append("No physical inspection result is available; all causes below are unverified.")

    steps = ["Verify the cooling-unit readings on site."]
    if unit and (unit["performance"] < 0.8 or unit["status"] == "degraded"): steps.append(f"Inspect cooling unit {unit['unit_id']}.")
    steps += ["Simulate alternative workload placement (Workload-to-Thermal Matching).",
              "Create a maintenance request if an operator confirms the issue."]
    return {"rack_id": rack_id, "title": f"{rack_id} temperature investigation",
            "status": "Investigation required" if est["level"] in ("Critical", "Elevated") else "Monitor",
            "observed_evidence": obs, "possible_factors": ranked, "similar_incidents": similar, "data_gaps": gaps,
            "recommended_next_steps": steps, "tags": derive_tags(est, unit, maint, hist),
            "caveat": "These are possible contributing factors supported by available evidence, not a confirmed diagnosis."}

def to_markdown(rep):
    L = [f"# {rep['title']}", f"**Status:** {rep['status']}", "", "## Observed evidence"]
    L += [f"- {o['fact']}  _(source: {o['source']})_" for o in rep["observed_evidence"]]
    L += ["", "## Possible contributing factors (unverified)"]
    for i, h in enumerate(rep["possible_factors"], 1):
        L.append(f"{i}. **{h['factor']}** - {h['support']} support")
        L += [f"   - for: {x}" for x in h["supporting"]] + [f"   - against: {x}" for x in h["against"]]
    if rep["similar_incidents"]:
        L += ["", "## Similar historical incidents"] + [f"- {s['incident_id']} (similarity {s['similarity']}): {s['resolution']}" for s in rep["similar_incidents"]]
    L += ["", "## Data gaps"] + [f"- {g}" for g in rep["data_gaps"]]
    L += ["", "## Recommended next steps"] + [f"- {s}" for s in rep["recommended_next_steps"]]
    L += ["", f"_{rep['caveat']}_"]
    return "\n".join(L)
